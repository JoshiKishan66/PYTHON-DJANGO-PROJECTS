from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Categories)
admin.site.register(Expense)
admin.site.register(SignUp)
admin.site.register(Contact)
admin.site.register(Subscribe)
admin.site.register(Faqs)