from django.apps import AppConfig


class ExpensetrackConfig(AppConfig):
    name = 'SmartFinance'
